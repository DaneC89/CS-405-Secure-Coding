// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());

    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // adds 5 entries
    add_entries(5);

    // Check the number of entries is equal to 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    // test for an empty collection
    ASSERT_GE(collection->max_size(), collection->size());

    // test for a collection with one entry
    collection->push_back(42);
    ASSERT_GE(collection->max_size(), collection->size());

    // test for a collection with five entries
    add_entries(4);
    ASSERT_GE(collection->max_size(), collection->size());

    // test for a collection with ten entries
    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
} 

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    // test for an empty collection
    ASSERT_GE(collection->capacity(), collection->size());

    // test for a collection with one entry
    collection->push_back(42);
    ASSERT_GE(collection->capacity(), collection->size());

    // test for a collection with five entries
    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    // test for a collection with ten entries
    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    // add some entries to the collection
    add_entries(5);

    // resize the collection to 10
    collection->resize(10);

    // the size of the collection should now be 10
    ASSERT_EQ(collection->size(), 10);

    // iterate over the first 5 entries to check that they still have their original value
    for (auto i = 0; i < 5; ++i)
    {
        ASSERT_EQ(collection->at(i), (*collection)[i]);
    }

    // the last 5 entries should be equal to 0
    for (auto i = 5; i < 10; ++i)
    {
        ASSERT_EQ(collection->at(i), 0);
    }
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    // Add 10 entries to the collection
    add_entries(10);
    int original_size = collection->size();

    // Resize the collection to 5
    collection->resize(5);
    int new_size = collection->size();

    ASSERT_LT(new_size, original_size);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
    // Add 10 entries to the collection
    add_entries(10);

    // Resize the collection to 0
    collection->resize(0);

    // Verify that the collection is now empty and has a size of 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add 10 entries
    add_entries(10);

    // Clear the collection
    collection->clear();

    // Verify that the collection is now empty and has a size of 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseCollection)
{
    // Add 10 entries
    add_entries(10);

    // Erase the entire collection
    collection->erase(collection->begin(), collection->end());

    // Verify that the collection is now empty and has a size of 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacity)
{
    // Reserve space for 10 entries
    collection->reserve(10);
    int original_capacity = collection->capacity();

    // Reserve space for 20 entries
    collection->reserve(20);
    int new_capacity = collection->capacity();

    // Verify that the new capacity is greater than the original capacity and that the size is still 0
    ASSERT_GT(new_capacity, original_capacity);
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeExceptionThrown)
{
    // Add 10 entries to the collection
    add_entries(10);

    // Verify that an exception is thrown when calling at() with an index greater than the size of the collection
    ASSERT_THROW(collection->at(20), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Positive test - Check if sorting a vector of integers sorts them in ascending order
TEST_F(CollectionTest, SortCollectionInAscendingOrder)
{
    // Add 10 random integers to the collection
    add_entries(10);
    // Sort the collection
    std::sort(collection->begin(), collection->end());

    // Verify that the elements are sorted in ascending order
    for (int i = 1; i < collection->size(); i++)
    {
        ASSERT_LE(collection->at(i - 1), collection->at(i));
    }
}

// Negative test - Check if an empty vector throws an exception when calling at()
TEST_F(CollectionTest, EmptyVectorAtThrowsException)
{
    // Verify that an exception is thrown when calling at() on an empty collection
    ASSERT_THROW(collection->at(0), std::out_of_range);
}