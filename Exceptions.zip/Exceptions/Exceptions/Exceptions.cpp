// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception derived from std::exception
class MyCustomException : public std::exception
{
public:
    // Override the what() function to return a custom exception message
    const char* what() const noexcept override
    {
        return "MyCustomException occurred!";
    }
};

// Function to perform even more custom application logic
bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    
    // Display message to console
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Return true to indicate success
    return true;
}

// Function to perform custom application logic
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    // Display message to console
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            // Display message to console if do_even_more_custom_application_logic() succeeded
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }

        // TODO: Throw a custom exception derived from std::exception
        //  and catch it explicitly in main

        // Throw a custom exception
        throw MyCustomException();
    }
    catch (const std::exception& e)
    {
        // Display message to console with the caught exception's what() message
        std::cout << "Caught std::exception: " << e.what() << std::endl;
    }

    // Display message to console
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function to divide two numbers, throws an exception if denominator is zero
float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    
    // Check if denominator is zero
    if (den == 0)
    {
        // Throw an invalid argument exception with a custom message
        throw std::invalid_argument("Denominator cannot be zero.");
    }

    // Calculate and return the division result if denominator is not zero
    return (num / den);
}

// Function to demonstrate exception handling with divide() function
void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    // Set numerator and denominator values
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        // Call the divide function and store the result
        auto result = divide(numerator, denominator);
        // Display the result to console
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        // Display a custom message for the caught exception
        std::cout << "Caught std::invalid_argument: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.

    // Try block to catch exceptions
    try
    {
        // Call function that throws exception
        do_division();
        // Call function that throws both standard and custom exceptions
        do_custom_application_logic();
    }
    // Catch block to catch custom exception derived from std::exception
    catch (const MyCustomException& e)
    {
        std::cout << "Caught MyCustomException: " << e.what() << std::endl;
    }
    // Catch block to catch standard exception
    catch (const std::exception& e)
    {
        std::cout << "Caught std::exception: " << e.what() << std::endl;
    }
    // Catch block to catch any other uncaught exception
    catch (...)
    {
        std::cout << "Caught uncaught exception!" << std::endl;
    }

    // Print final message to console
    std::cout << "End of program." << std::endl;

    // Return 0 to indicate successful program completion
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

